library(testthat)
library(crosslinks)

test_check("crosslinks")
