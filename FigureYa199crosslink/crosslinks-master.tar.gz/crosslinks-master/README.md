# crosslinks
Plot cross lines in square and columns.  
Publication vs crosslinks plot.  
<img src="https://github.com/zzwch/crosslinks/raw/master/pic/publication.jpeg" width="400"><img src="https://github.com/zzwch/crosslinks/raw/master/pic/plot.jpeg" width="400">
