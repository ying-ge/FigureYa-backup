library(testthat)
library(plsRcox)

test_check("plsRcox")
