is.rate <- function(x)
  x %in% .settings$sm4rate
