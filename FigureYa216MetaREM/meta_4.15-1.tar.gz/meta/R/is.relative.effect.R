is.relative.effect <- function(x)
  x %in% c("HR", "OR", "RR", "IRR", "ROM", "DOR")
