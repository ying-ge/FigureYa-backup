library(testthat)
library(ScBulkCCCI)

test_check("ScBulkCCCI")
