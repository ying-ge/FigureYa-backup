test_that("multiplication works", {
	#expect_equal(2 * 2, 4)
	library("igraph")
  library("RColorBrewer")
	tumor_subtype_ES= read.table("../../data/tumor_subtype.Correlative.cell_cell.interactions.txt", header = T, sep = "\t")
	networkData = dplyr::filter(tumor_subtype_ES, EnrichScore>1.96, specificSubtype != otherSubtype)
	CRC_Leukocyte_SM_MD = read.table("../../data/CRC.Leukocyte.Smart-seq2.Metadata.txt",header = T, sep="\t", check.names = F);dim(CRC_Leukocyte_SM_MD)
	overlap = intersect(unique(c(networkData$specificSubtype,networkData$otherSubtype)), CRC_Leukocyte_SM_MD$Sub_Cluster)

	nodes <- dplyr::filter(CRC_Leukocyte_SM_MD,Sub_Cluster %in% overlap) %>%
	  select(Sub_Cluster, Global_Cluster) %>%
	  dplyr::distinct(Sub_Cluster,Global_Cluster)

	nodes = merge(data.frame(node = unique(c(networkData$specificSubtype,networkData$otherSubtype))), nodes, by.x="node", by.y="Sub_Cluster", all = T)
	nodes[is.na(nodes)] ="Not annotation"


	g <- graph_from_data_frame(networkData, directed=F, vertices=nodes)
	V(g)$label.cex=0.75
	V(g)$label.color <- "black"
	V(g)$color <- brewer.pal(n = 12, name ="Paired")[as.numeric(as.factor(V(g)$Global_Cluster))]
	V(g)$frame.color <- "white"
	plot(g)

	legend(x=-1.5, y= 1, unique(as.factor(V(g)$Global_Cluster)), pch=21,
		   col="#777777", pt.bg=unique(brewer.pal(n = 12, name ="Paired")[as.numeric(as.factor(V(g)$Global_Cluster))]),
		   pt.cex=2, cex=.8, bty="n", ncol=1)

})
