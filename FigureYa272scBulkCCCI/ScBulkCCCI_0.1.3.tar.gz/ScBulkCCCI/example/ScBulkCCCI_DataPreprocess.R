library(dplyr)
library(stringr)
library(plyr)
library(tibble)
library(tidyr)

# Import ScRNAseq Smart-seq2
CRC_Leukocyte_SM_MD = read.table("CRC.Leukocyte.Smart-seq2.Metadata.txt",header = T, sep="\t", check.names = F);dim(CRC_Leukocyte_SM_MD)
CRC_Leukocyte_SM_RNA = read.table("CRC.Leukocyte.Smart-seq2.TPM.txt",header = T)
#saveRDS(CRC_Leukocyte_SM_MD, file="CRC.Leukocyte.Smart-seq2.Metadata.rds")
#saveRDS(CRC_Leukocyte_SM_RNA, file="CRC.Leukocyte.Smart-seq2.TPM.rds")

# Gene signatures for each subtype from Smart-seq2
## Normal enriched clusters
CCgene_normal = read.table("T4.Normal_enriched.txt", header = T, sep = "\t", check.names = F); dim(CCgene_normal)
CCgene_normal = stack(CCgene_normal) %>%
  plyr::rename(c("values" ="gene", "ind" ="cluster")) %>%
  dplyr::filter(grepl(pattern="^\\S+$", gene, perl = T)); dim(CCgene_normal)
write.table(CCgene_normal, file = "CCgene.Normal_enriched.txt", quote = F, row.names = F, sep = "\t")
saveRDS(CCgene_normal, file = "CCgene_normal.rds")

## Tumor enriched clusters
CCgene_tumor = read.table("T4.Tumor_enriched.txt", header = T, sep = "\t", check.names = F); dim(CCgene_tumor)
CCgene_tumor = stack(CCgene_tumor) %>%
  plyr::rename(c("values" ="gene", "ind" ="cluster")) %>%
  dplyr::filter(grepl(pattern="^\\S+$", gene, perl = T)); dim(CCgene_tumor)
write.table(CCgene_tumor, file = "CCgene.Tumor_enriched.txt", quote = F, row.names = F, sep = "\t")
saveRDS(CCgene_tumor, file = "CCgene_tumor.rds")
# Bulk expression profiles
## GTEX data
### gtex phenotype
GTEX_phenotype = read.table("GTEX_phenotype", header = T, sep = "\t", check.names = F)
GTEX_phenotype_filter = filter(GTEX_phenotype, grepl("^Colon", primary_site))

### gtex Genomic
GTEX_colon = read.table("gtex_RSEM_gene_tpm", header = T, sep = "\t", row.names = 1, check.names=FALSE)
GTEX_colon = GTEX_colon[, colnames(GTEX_colon) %in% GTEX_phenotype_filter$Sample]; dim(GTEX_colon)

### Import gene ID/Gene data
geneInfo = read.table("GTEX.probeMap_gencode.v23.annotation.gene.probemap", header = T, check.names = F); dim(geneInfo)

### Transform gene ID
dataMerge_normal <- merge(GTEX_colon ,geneInfo[,c("id", "gene")], by.x="row.names", by.y="id",all = FALSE) %>%
  column_to_rownames(var = "Row.names");dim(dataMerge_normal)

### filter genes
dataMerge_normal = dataMerge_normal %>%filter(gene %in% row.names(CRC_Leukocyte_SM_RNA));dim(dataMerge_normal)# #CRC_Leukocyte_SM_RNA 14862   309
dataMerge_normal = dataMerge_normal[!(apply(dplyr::select(dataMerge_normal, -gene), 1, function(x){ all(x==mean(x))})),];dim(dataMerge_normal) #14839   309
#dataMerge_normal = dataMerge_normal[,!(apply(dplyr::select(dataMerge_normal, -gene), 2, function(x){ all(x==mean(x))}))];dim(dataMerge_normal) #14839   309

### All genes
dataMerge_normal_allgene = dataMerge_normal %>% 
  drop_na() %>% #dataMerge[complete.cases(dataMerge),] %>% 
  dplyr::mutate(meanValue = rowMeans(across(where(is.numeric)))) %>%
  arrange(desc(meanValue)) %>%
  dplyr::distinct(gene, .keep_all = TRUE) %>%
  #column_to_rownames(var="gene") %>%
  dplyr::select(-meanValue); dim(dataMerge_normal_allgene) #14783   309

### specific gene signatures
# dim(CCgene_normal)
# dataMerge_normal_signature = dataMerge_normal_allgene[dataMerge_normal_allgene$gene %in% CCgene_normal$gene,];dim(dataMerge_normal_signature) #191 309

dataMerge_normal_allgene = dataMerge_normal_allgene %>%
  tibble::remove_rownames() %>%
  column_to_rownames(var="gene") ;dim(dataMerge_normal_allgene) #14783   308

# dataMerge_normal_signature = dataMerge_normal_signature %>%
#   remove_rownames() %>%
#   column_to_rownames(var="gene") ;dim(dataMerge_normal_signature) #191 308

#write.table(dataMerge_normal_allgene, file = "dataMerge_normal_allgene.txt", row.names = T, quote = F, sep = "\t")
#write.table(dataMerge_normal_signature, file = "dataMerge_normal_signature.txt", row.names = T, quote = F, sep = "\t")
saveRDS(dataMerge_normal_allgene, file = "dataMerge_normal_allgene.rds")

## TCGA data
### TCGA phenotype
TCGA_phenotype = read.table("TCGA.COADREAD.sampleMap_COADREAD_clinicalMatrix", header = T, sep = "\t", check.names = F)
#TCGA_phenotype_filter = filter(TCGA_phenotype, grepl("^Colon", body_site_detail..SMTSD.))

### TCGA Genomic
TCGA_colon = read.table("TCGA.COADREAD.sampleMap_HiSeqV2", header = T, sep = "\t", row.names = 1, check.names=FALSE);dim(TCGA_colon) #20530   434
TCGA_colon = TCGA_colon[, colnames(TCGA_colon) %in% TCGA_phenotype$sampleID]; dim(TCGA_colon);dim(TCGA_colon)

### Import gene ID/Gene data
geneInfo = read.table("TCGA.probeMap_hugo_gencode_good_hg19_V24lift37_probemap", header = T, check.names = F)

### Transform gene ID
dataMerge_tumor <- merge(TCGA_colon ,geneInfo[,c("id", "gene")], by.x="row.names", by.y="id",all = FALSE) %>%
  column_to_rownames(var = "Row.names")

### filter genes
dataMerge_tumor = dataMerge_tumor %>%filter(gene %in% row.names(CRC_Leukocyte_SM_RNA));dim(dataMerge_tumor)# #CRC_Leukocyte_SM_RNA 13194   435
dataMerge_tumor = dataMerge_tumor[!(apply(dplyr::select(dataMerge_tumor, -gene), 1, function(x){ all(x==mean(x))})),];dim(dataMerge_tumor) #13194   435
#dataMerge_tumor = dataMerge_tumor[,!(apply(dplyr::select(dataMerge_tumor, -gene), 2, function(x){ all(x==mean(x))}))];dim(dataMerge_tumor)


### All genes
dataMerge_tumor_allgene = dataMerge_tumor %>% 
  drop_na() %>% #dataMerge[complete.cases(dataMerge),] %>% 
  dplyr::mutate(meanValue = rowMeans(across(where(is.numeric)))) %>%
  arrange(desc(meanValue)) %>%
  distinct(gene, .keep_all = TRUE) %>%
  select(-meanValue); dim(dataMerge_tumor_allgene) #13194   435

# ### specific gene signatures
# dataMerge_tumor_signature = dataMerge_tumor_allgene[dataMerge_tumor_allgene$gene %in% CCgene_tumor$gene,];dim(dataMerge_tumor_signature) #251 435

dataMerge_tumor_allgene = dataMerge_tumor_allgene %>%
  remove_rownames() %>%
  column_to_rownames(var="gene")

# dataMerge_tumor_signature = dataMerge_tumor_signature %>%
#   remove_rownames() %>%
#   column_to_rownames(var="gene")

#write.table(dataMerge_tumor_allgene, file = "dataMerge_tumor_allgene.txt", row.names = T, quote = F)
#write.table(dataMerge_tumor_signature, file = "dataMerge_tumor_signature.txt", row.names = T, quote = F)
saveRDS(dataMerge_tumor_allgene, file = "dataMerge_tumor_allgene.rds")

