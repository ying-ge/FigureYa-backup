
library("pheatmap")
library("RColorBrewer")
library("ScBulkCCCI")

# Import data
libPath <- find.package("ScBulkCCCI")
## Import ScRNAseq Smart-seq2
CRC_Leukocyte_SM_MD = read.table(paste(libPath, "/data/CRC.Leukocyte.Smart-seq2.Metadata.txt",sep=""),header = T, sep="\t", check.names = F);dim(CRC_Leukocyte_SM_MD)
CRC_Leukocyte_SM_RNA = read.table(paste(libPath, "/data/CRC.Leukocyte.Smart-seq2.TPM.txt",sep=""),header = T)
# CRC_Leukocyte_SM_MD = readRDS("CRC.Leukocyte.Smart-seq2.Metadata.rds");dim(CRC_Leukocyte_SM_MD)
# CRC_Leukocyte_SM_RNA = readRDS("CRC.Leukocyte.Smart-seq2.TPM.rds");dim(CRC_Leukocyte_SM_RNA)

## Import gene signatures for each subtype from Smart-seq2
CCgene_normal = readRDS(paste(libPath, "/data/CCgene_normal.rds",sep=""))
CCgene_tumor = readRDS(paste(libPath, "/data/CCgene_tumor.rds",sep=""))

## Import bulk expression profiles
dataMerge_normal_allgene = readRDS(paste(libPath, "/data/dataMerge_normal_allgene.rds",sep=""))
dataMerge_tumor_allgene = readRDS(paste(libPath, "/data/dataMerge_tumor_allgene.rds",sep=""))

# Tissue distribution of clusters
#CRC.Leukocyte.10x.Metadata.txt: https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE146771
CRC_Leukocyte_10x_MD = read.table(paste(libPath, "./data/CRC.Leukocyte.10x.Metadata.txt",sep=""),header = T, sep="\t", check.names = F);dim(CRC_Leukocyte_10x_MD)
CRC_Leukocyte_10x_MD_FIilter = filter(CRC_Leukocyte_10x_MD, grepl("^hM",Sub_Cluster))
Roe = calTissueDist(CRC_Leukocyte_10x_MD_FIilter,colname.cluster="Sub_Cluster", colname.tissue="Tissue")
pheatmap::pheatmap(Roe, cluster_rows = F, cluster_cols = F, color = colorRampPalette(brewer.pal(n = 7, name ="YlOrRd"))(50),
                   display_numbers = TRUE,number_color = "black")

# Construct cell subtype abundance correlation matrix
cor_matrix_normal = corMatrix(CCgene_normal, cluste = "cluster", dataMerge_normal_allgene);dim(cor_matrix_normal) #14783    17
cor_matrix_tumor = corMatrix(CCgene_tumor, cluste = "cluster", dataMerge_tumor_allgene);dim(cor_matrix_tumor) #13194    22

# Enrichment analysis for highly correlated genes
## Case 1. For a specific cell subtype and another cell subtype
### Case 1.1 Obtain the ranked correlated non-self-expressed genes for a specific cell subtype
##highCorGene Function():
##Achievement: the ranked correlated non-self-expressed genes from the adjusted correlation matrix for a specific cell subtype
##step 1. Identify self-expressed genes
##step 2. Adjust correlation matrix by self-expressed genes
subcluter_name= unique(CCgene_normal$cluster)[1] #unique(CCgene_normal$cluster)[1] #unique(CCgene_normal$cluster)[1]


highCorNonSelfGenes = highCorGene(subcluter_name= subcluter_name,
                                  Sub_Cluster="Sub_Cluster", CellName="CellName",
                                  cellMetaData= CRC_Leukocyte_SM_MD, ScExMatrix=CRC_Leukocyte_SM_RNA,
                                  cor_matrix=cor_matrix_normal,TopMethod="Positive")
highCorNonSelfGenes$correlatioRankPlot

### Case 1.2 Enrichment analysis for a specific cell subtype and another cell subtype
subcluter_name2= unique(CRC_Leukocyte_SM_MD$Sub_Cluster)[2]

subtypeEnrichScore = EnrichCorGene(subcluter_name2= subcluter_name2,
                                   topCorGene=names(highCorNonSelfGenes$CorGeneRank[1:13]),
                                   cellMetaData= CRC_Leukocyte_SM_MD, ScExMatrix=CRC_Leukocyte_SM_RNA,
                                   Sub_Cluster="Sub_Cluster", CellName="CellName")
cat(as.character(subcluter_name), as.character(subcluter_name2), subtypeEnrichScore)


## Case 2. For a specific cell subtype and multiple cell subtype
allClusters = unique(c(CCgene_normal$cluster, CCgene_tumor$cluster)) #unique(CRC_Leukocyte_SM_MD$Sub_Cluster)

ES = oneToMultiple(allClusters= allClusters,
                   topCorGene=names(highCorNonSelfGenes$CorGeneRank[1:13]),
                   cellMetaData= CRC_Leukocyte_SM_MD, ScExMatrix=CRC_Leukocyte_SM_RNA,
                   Sub_Cluster="Sub_Cluster", CellName="CellName")
scale(na.omit(ES))
ESData = data.frame(name = rownames(scale(na.omit(ES))),ES=scale(na.omit(ES)))
ESData$colorInfo = as.factor(ifelse(ESData$ES>0, "pos", "neg"))
library(ggplot2)
library(ggthemes)
ggplot() + geom_bar(data = ESData,aes(x=name, y=ES, fill=colorInfo),stat = "identity") +
  geom_hline(yintercept=1, color="blue", linetype="dashed") +
  scale_fill_manual(values=c("#87CEFA", "#6495ED")) +
  labs(x = "Correlative cell cluster", y = "Enrichment score", title = paste("Enrichment analysis for",subcluter_name,sep = " ")) +
  theme_base() +
  theme(axis.text.x = element_text(size = 15, vjust = 0.5, hjust = 0.5, angle = 90)) +
  theme(legend.position="none") +
  theme(plot.title = element_text(hjust = 0.5))



## Case 3. For multiple cell subtypes and multiple cell subtypes
allClusters = unique(c(CCgene_normal$cluster, CCgene_tumor$cluster)) #unique(c(CCgene_normal$cluster, CCgene_tumor$cluster)) #unique(CRC_Leukocyte_SM_MD$Sub_Cluster)
topGeneNum=13
{
  normal_subtype_ES = cellCellInteraction(specificSubtypes = unique(CCgene_normal$cluster),
                                          allClusters = allClusters, # unique(c(CCgene_normal$cluster, CCgene_tumor$cluster)), #unique(CRC_Leukocyte_SM_MD$Sub_Cluster)
                                          cor_matrix = cor_matrix_normal,
                                          cellMetaData= CRC_Leukocyte_SM_MD,
                                          ScExMatrix=CRC_Leukocyte_SM_RNA,
                                          Sub_Cluster="Sub_Cluster",
                                          CellName="CellName",
                                          topGeneNum = topGeneNum,
                                          TopMethod="Positive")

  tumor_subtype_ES = cellCellInteraction(specificSubtypes = unique(CCgene_tumor$cluster),
                                         allClusters = allClusters,#unique(c(CCgene_normal$cluster, CCgene_tumor$cluster)),
                                         cor_matrix = cor_matrix_tumor,
                                         cellMetaData= CRC_Leukocyte_SM_MD,
                                         ScExMatrix=CRC_Leukocyte_SM_RNA,
                                         Sub_Cluster="Sub_Cluster",
                                         CellName="CellName",
                                         topGeneNum = topGeneNum,
                                         TopMethod="Positive")
}

#write.table(tumor_subtype_ES, file = paste(libPath, "/data/tumor_subtype.Correlative.cell_cell.interactions.txt",sep=""), quote = F, row.names = F, sep = "\t") #unique(CRC_Leukocyte_SM_MD$Sub_Cluster)

#write.table(subtype_ES, file = paste(libPath, "/data/Correlative.cell_cell.interactions.txt",sep=""), quote = F, row.names = F, sep = "\t") #unique(CRC_Leukocyte_SM_MD$Sub_Cluster)

# Plot the result of Enrichment analysis


## Plot network by igraph
library("igraph")
tumor_subtype_ES= read.table(paste(libPath, "/data/tumor_subtype.Correlative.cell_cell.interactions.txt",sep=""), header = T, sep = "\t")
networkData = dplyr::filter(tumor_subtype_ES, EnrichScore>1.96, specificSubtype != otherSubtype)
CRC_Leukocyte_SM_MD = read.table(paste(libPath, "/data/CRC.Leukocyte.Smart-seq2.Metadata.txt",sep=""),header = T, sep="\t", check.names = F);dim(CRC_Leukocyte_SM_MD)
overlap = intersect(unique(c(networkData$specificSubtype,networkData$otherSubtype)), CRC_Leukocyte_SM_MD$Sub_Cluster)

nodes <- dplyr::filter(CRC_Leukocyte_SM_MD,Sub_Cluster %in% overlap) %>%
  select(Sub_Cluster, Global_Cluster) %>%
  dplyr::distinct(Sub_Cluster,Global_Cluster)

nodes = merge(data.frame(node = unique(c(networkData$specificSubtype,networkData$otherSubtype))), nodes, by.x="node", by.y="Sub_Cluster", all = T)
nodes[is.na(nodes)] ="Not annotation"


g <- graph_from_data_frame(networkData, directed=F, vertices=nodes)
V(g)$label.cex=0.75
V(g)$label.color <- "black"
V(g)$color <- brewer.pal(n = 12, name ="Paired")[as.numeric(as.factor(V(g)$Global_Cluster))]
V(g)$frame.color <- "white"
plot(g)

legend(x=-1.5, y= 1, unique(as.factor(V(g)$Global_Cluster)), pch=21,
       col="#777777", pt.bg=unique(brewer.pal(n = 12, name ="Paired")[as.numeric(as.factor(V(g)$Global_Cluster))]),
       pt.cex=2, cex=.8, bty="n", ncol=1)

## Plot dynamic network
library(magrittr)
library(networkD3)
nodeData <- data.frame(name=nodes$node,
                       group= as.factor(nodes$Global_Cluster))
linkData <- data.frame(source = (match(networkData$specificSubtype, nodeData$name)-1),
                       target = (match(networkData$otherSubtype, nodeData$name)-1))
forceNetwork(
  Links = linkData,
  Nodes = nodeData,
  Source = "source",
  Target = "target",
  NodeID = "name",Group = "group", legend = T, opacityNoHover = 1,zoom=T) %>%
  saveNetwork(file = './network.html')
