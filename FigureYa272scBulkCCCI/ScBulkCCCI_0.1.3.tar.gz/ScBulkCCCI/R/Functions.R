# library("ggplot2")
# library("ggthemes")
# library("plyr")
# library("dplyr")
# library("stringr")
# library("tibble")
# library("tidyr")


#' z-score
#'
#' @param x A numerical vaector.
#' @param method.
#'
#' @return
#' @export
#'
#' @examples
#' Z_score(c(1:10))
Z_score <- function(x, method = "zs") {
  if (method == "zs") {
    return((x - mean(x)) / sd(x))
  } else if (method == "none") {
    return(x)
  }
}


#' Abundance function
#'
#' @param count matix
#' @param logTransform Whether log transform data
#'
#' @return
#' @export
#'
#' @examples
cellType_abundance=function(count, logTransform =F){
  if(logTransform == F){
    return(
      rowMeans(apply(count, 1, function(x){Z_score(x, method="zs")})) #rowMeans(scale(t(count)))
      #colMeans(colMeans)

    )
  }else if(logTransform == T){
    return(
      rowMeans(apply(count, 2, function(x){Z_score(log(x+1), method="none")}))
    )
  }
}

#' corMatrix Function(): Construct cell subtype abundance correlation matrix
#' step 1. Filter specific gene signatures for each subtype in bulk RNAseq
#' step 2. Construct correlation matrix for each subtype
#' step 3. Merge correlation matrix for all cell subtype
#'
#' @param CCgene_info specific gene signatures data;first column is gene name, second column is cell subtype
#' @param cluster cluster column in CCgene_info
#' @param dataMerge_allgene Bulk RNAseq matrix, row represent genes, column represent sample.
#' @param corMethod One of "pearson" (default), "kendall", or "spearman" used in correlation calculation.
#'
#' @return
#' @export
#'
#' @examples
#' cor_matrix_normal <- corMatrix(CCgene_normal, cluste = "cluster", dataMerge_normal_allgene)
corMatrix <- function(CCgene_info, cluster = "cluster", dataMerge_allgene, corMethod = "pearson") {
  clusters <- unique(CCgene_info[[cluster]])
  for (subcluter_name in clusters) {
    cat("Doning", subcluter_name, "\n")
    subtype <- CCgene_info[CCgene_info[[cluster]] %in% subcluter_name, ]
    dataMerge_subtype <- dataMerge_allgene[row.names(dataMerge_allgene) %in% subtype$gene, ]
    dim(dataMerge_allgene)

    cat("The gene signatures of", subcluter_name, ": ", nrow(subtype), "; Use", nrow(dataMerge_subtype), "genes", "\n")

    # Caculate abundance of cell subcluster
    GTEX_abundance <- cellType_abundance(dataMerge_subtype)
    length(GTEX_abundance)

    # Check NA in abundance which caused by poor raw data
    if (sum(is.na(GTEX_abundance) > 0)) {
      cat(length(GTEX_abundance), "samples; ", sum(is.na(GTEX_abundance)), " NA in", subcluter_name, "abundance.", "\n")
    } else {
      cat(length(GTEX_abundance), "samples in", subcluter_name, "abundance.", "\n")
    }

    # Computed the pearson correlation coefficient between the expression of each gene and the abundance of each cell subtype
    gene_cor <- dataMerge_allgene %>%
      apply(1, function(x) {
        cor(as.numeric(x), as.numeric(GTEX_abundance), use = "complete.obs", method = corMethod)
      })

    gene_cor <- as.data.frame(gene_cor) %>%
      plyr::rename(c(gene_cor = subcluter_name))

    if (match(subcluter_name, clusters) == 1) {
      cor_matrix <- as.data.frame(gene_cor)
    } else {
      cor_matrix <- cbind(cor_matrix, gene_cor)
    }
  }
  return(cor_matrix)
}
# Run example
# cor_matrix_normal = corMatrix(CCgene_normal, cluste = "cluster", dataMerge_normal_allgene);dim(cor_matrix_normal)

#' highCorGene Function(): the top highly correlated non-self-expressed genes were selected from the adjusted correlation matrix
#' step 1. Identify self-expressed genes
#' step 2. Adjust correlation matrix by self-expressed genes
#'
#' @param subcluter_name A cell subtypes name
#' @param Metadata Cell type annotation file, Metadata = CRC_Leukocyte_SM_MD
#' @param Sub_Cluster Sub_Cluster column in Metadata
#' @param CellName Cell name column in Metadata
#' @param ScExMatrix Normlized single cell RNAseq ;ScExMatrix = CRC_Leukocyte_SM_RNA
#' @param TopMethod Positive, Negative, AbsoluteValue
#'
#' @return
#' @export
#'
#' @examples
#' highCorNonSelfGenes <- highCorGene(
#'   subcluter_name = unique(CCgene_normal$cluster)[1],
#'   Sub_Cluster = "Sub_Cluster",
#'   CellName = "CellName",
#'   cellMetaData = CRC_Leukocyte_SM_MD, ScExMatrix = CRC_Leukocyte_SM_RNA,
#'   cor_matrix = cor_matrix, TopMethod = "Positive"
#' )
highCorGene <- function(subcluter_name, cellMetaData, Sub_Cluster = "Sub_Cluster", CellName = "CellName", ScExMatrix, cor_matrix, TopMethod = "Positive") {
  # sub_type_cell = filter(cellMetaData, Sub_Cluster == subcluter_name); dim(sub_type_cell)
  sub_type_cell <- cellMetaData[cellMetaData[[Sub_Cluster]] %in% subcluter_name, ]

  # Extract cell Smart-seq2
  subcluter_matrix <- ScExMatrix %>%
    select(sub_type_cell[[CellName]])
  dim(subcluter_matrix)

  # Identify self-expressed genes based on our Smart-seq2 dataset
  gene_averageExpression <- rowMeans(subcluter_matrix)
  cell_frequence <- apply(subcluter_matrix, 1, function(x) {
    sum(x > 0) / length(x)
  })

  # (1) average expression > 1; (2) cell frequency of expression > 20%
  self_expressed_genes <- data.frame(gene_averageExpression = gene_averageExpression, cell_frequence = cell_frequence) %>%
    dplyr::filter((gene_averageExpression > 1) & (cell_frequence > 0.2))

  cat("The number of self-expressed genes:", nrow(self_expressed_genes), "; Other genes:", length(gene_averageExpression) - nrow(self_expressed_genes), "\n")

  # Adjust correlation matrix by self-expressed genes
  cor_matrix_adj <- cor_matrix[[subcluter_name]]
  names(cor_matrix_adj) <- rownames(cor_matrix)
  # cor_matrix_adj[rownames(self_expressed_genes)] = 0
  cor_matrix_adj[names(cor_matrix_adj) %in% rownames(self_expressed_genes)] <- 0

  # TopMethod: Positive, Negative, AbsoluteValue
  if (TopMethod == "Positive") {
    cor_matrix_adj <- sort(cor_matrix_adj, decreasing = T)
  } else if (TopMethod == "Negative") {
    cor_matrix_adj <- sort(cor_matrix_adj, decreasing = F)
  } else if (TopMethod == "AbsoluteValue") {
    cor_matrix_adj <- cor_matrix_adj[order(abs(cor_matrix_adj), decreasing = T)] # sort(abs(cor_matrix_adj), decreasing = T)
  }
  # plot(cor_matrix_adj, xlab="Correlation rank", ylab ="Correlation score")
  # Correlation_rank_plot <-recordPlot()
  Correlation_rank_plot <- qplot(
    x = seq_len(length(cor_matrix_adj)), y = cor_matrix_adj, # 1:length(cor_matrix_adj)
    main = "The pearson correlation between genes and each cell subtype",
    xlab = "Correlation rank", ylab = "Correlation score"
  ) + theme_base()

  # Overlap genes between Single RNAseq and Bulk RNAseq
  # cor_matrix_adj = cor_matrix_adj[names(cor_matrix_adj) %in% rownames(ScExMatrix)]; length(cor_matrix_adj) #14783
  # top13 = cor_matrix_adj[1:13]
  return(list(CorGeneRank = cor_matrix_adj, correlatioRankPlot = Correlation_rank_plot))
}


#' EnrichCorGene Function(): Enrichment analysis for highly correlated genes
#' step 1. Obtain theexpression of highly correlated genes in another cell subtype
#' step 2. Z-score, mean
#'
#' @param subcluter_name2  Another cell subtype
#' @param topCorGene  For a specific cell subtype, whose highly correlated non-self-expressed genes
#' @param Metadata  Cell type annotation file, Metadata = CRC_Leukocyte_SM_MD
#' @param Sub_Cluster  Sub_Cluster column in Metadata
#' @param CellName  Cell name column in Metadata
#' @param ScExMatrix  Normlized single cell RNAseq ;ScExMatrix = CRC_Leukocyte_SM_RNA
#'
#' @return
#' @export
#'
#' @examples
#' subtypeEnrichScore <- EnrichCorGene(
#'   subcluter_name2 = unique(CCgene_normal$cluster)[3],
#'   topCorGene = names(highCorNonSelfGenes$CorGeneRank[1:13]),
#'   cellMetaData = CRC_Leukocyte_SM_MD, ScExMatrix = CRC_Leukocyte_SM_RNA,
#'   Sub_Cluster = "Sub_Cluster", CellName = "CellName"
#' )
EnrichCorGene <- function(subcluter_name2, topCorGene, cellMetaData, Sub_Cluster = "Sub_Cluster", CellName = "CellName", ScExMatrix) {
  # sub_type_cell2 = filter(cellMetaData, Sub_Cluster == subcluter_name2); dim(sub_type_cell2)
  sub_type_cell2 <- cellMetaData[cellMetaData[[Sub_Cluster]] %in% subcluter_name2, ]

  # Extract cell from Smart-seq2
  subcluter_matrix2 <- ScExMatrix %>%
    select(sub_type_cell2[[CellName]])
  dim(subcluter_matrix2)
  # Gene mean and z-score
  subcluter_enrich2 <- Z_score(rowMeans(subcluter_matrix2))
  # subcluter_enrich_score = mean(subcluter_enrich2[names(subcluter_enrich2) %in% names(top13)])
  subcluter_enrich_score <- mean(subcluter_enrich2[topCorGene])

  return(subcluter_enrich_score)
}

# Run example
# subtypeEnrichScore = EnrichCorGene(subcluter_name2= unique(CCgene_normal$cluster)[3],
#                                    topCorGene=names(highCorNonSelfGenes$CorGeneRank[1:13]),
#                                    cellMetaData= CRC_Leukocyte_SM_MD, ScExMatrix=CRC_Leukocyte_SM_RNA,
#                                    Sub_Cluster="Sub_Cluster", CellName="CellName"
#                                    )
# cat(as.character(unique(CCgene_normal$cluster)[1]), as.character(unique(CCgene_normal$cluster)[2]), subtypeEnrichScore)


# Z_score(subtypeEnrichScoreVector)

#' For a specific cell subtype and multiple cell subtype
#'
#' @param allClusters A string vector.
#' @param topCorGene Result from highCorGene() function.
#' @param cellMetaData cell meata data from ScRNAseq.
#' @param ScExMatrix ScRNAseq count matrix.
#' @param Sub_Cluster  column represent cluster name.
#' @param CellName column represent cell name.
#'
#' @return
#' @export
#'
#' @examples
#' ES <- oneToMultiple(
#'   subcluter_name2 = otherType,
#'   topCorGene = names(highCorNonSelfGenes$CorGeneRank[1:13]),
#'   cellMetaData = CRC_Leukocyte_SM_MD, ScExMatrix = CRC_Leukocyte_SM_RNA,
#'   Sub_Cluster = "Sub_Cluster", CellName = "CellName"
#' )
oneToMultiple <- function(allClusters, topCorGene, cellMetaData, ScExMatrix, Sub_Cluster = "Sub_Cluster", CellName = "CellName") {
  for (otherType in allClusters) {
    subtypeEnrichScore <- EnrichCorGene(
      subcluter_name2 = otherType,
      topCorGene = topCorGene,
      cellMetaData = cellMetaData, ScExMatrix = ScExMatrix,
      Sub_Cluster = "Sub_Cluster", CellName = "CellName"
    )
    names(subtypeEnrichScore) <- otherType
    # cat(as.character(subcluter_name), as.character(otherType), subtypeEnrichScore, "\n")

    if (match(otherType, allClusters) == 1) {
      subtypeEnrichScoreVector <- c(subtypeEnrichScore)
    } else {
      subtypeEnrichScoreVector <- append(subtypeEnrichScoreVector, subtypeEnrichScore)
    }
  }

  return(subtypeEnrichScoreVector)
}

# Run example
# ES = oneToMultiple(subcluter_name2= otherType,
#                    topCorGene=names(highCorNonSelfGenes$CorGeneRank[1:13]),
#                    cellMetaData= CRC_Leukocyte_SM_MD, ScExMatrix=CRC_Leukocyte_SM_RNA,
#                    Sub_Cluster="Sub_Cluster", CellName="CellName")
# Z_score(ES)
#
# for (subcluter_name in specificSubtypes) {
#
#   cat("A specific cell subtype", subcluter_name, "\n")
#   #Identify the top highly correlated non-self-expressed genes from the adjusted correlation matrix
#   highCorNonSelfGenes = highCorGene(subcluter_name= subcluter_name,
#                                     cellMetaData= cellMetaData, ScExMatrix=ScExMatrix,
#                                     cor_matrix=cor_matrix,TopMethod=TopMethod)
#
#   # Enrichment analysis for a specific cell subtype
#   for(otherType in allClusters){
#     subtypeEnrichScore = EnrichCorGene(subcluter_name2= otherType,
#                                        topCorGene=names(highCorNonSelfGenes$CorGeneRank[1:topGeneNum]),
#                                        cellMetaData= cellMetaData, ScExMatrix=ScExMatrix,
#                                        Sub_Cluster="Sub_Cluster", CellName="CellName")
#
#     names(subtypeEnrichScore) = otherType
#     cat(as.character(subcluter_name),
#         as.character(otherType), subtypeEnrichScore, "\n")
#
#     if(match(otherType, allClusters) == 1){
#       subtypeEnrichScoreVector = c(subtypeEnrichScore)
#     }else{
#       subtypeEnrichScoreVector = append(subtypeEnrichScoreVector, subtypeEnrichScore)
#     }
#   }
#   subtypeEnrichScoreTemp = data.frame(EnrichScore = Z_score(subtypeEnrichScoreVector),
#                                       specificSubtype = subcluter_name,
#                                       otherSubtype= names(Z_score(subtypeEnrichScoreVector))) %>% remove_rownames()
#   if(match(subcluter_name, specificSubtypes) == 1){
#     allTypeEnrichScore = subtypeEnrichScoreTemp
#   }else{
#     allTypeEnrichScore = rbind(allTypeEnrichScore, subtypeEnrichScoreTemp)
#   }
#
# }

# cellCellInteraction Function(): For multiple cell subtypes and multiple cell subtypes
#' Title
#'
#' @param specificSubtypes
#' @param allClusters
#' @param cor_matrix
#' @param cellMetaData
#' @param ScExMatrix
#' @param Sub_Cluster
#' @param CellName
#' @param topGeneNum
#' @param TopMethod
#'
#' @return
#' @export
#'
#' @examples
#' test <- cellCellInteraction(
#'   specificSubtypes = unique(CCgene_normal$cluster),
#'   allClusters = unique(c(CCgene_normal$cluster, CCgene_tumor$cluster)), # unique(CRC_Leukocyte_SM_MD$Sub_Cluster),
#'   cor_matrix = cor_matrix_normal,
#'   cellMetaData = CRC_Leukocyte_SM_MD,
#'   ScExMatrix = CRC_Leukocyte_SM_RNA,
#'   Sub_Cluster = "Sub_Cluster",
#'   CellName = "CellName",
#'   topGeneNum = 13,
#'   TopMethod = "Positive"
#' )
cellCellInteraction <- function(specificSubtypes,
                                allClusters,
                                cor_matrix,
                                cellMetaData,
                                ScExMatrix,
                                Sub_Cluster = "Sub_Cluster",
                                CellName = "CellName",
                                topGeneNum = 13,
                                TopMethod = "Positive") {
  for (subcluter_name in specificSubtypes) {
    cat("A specific cell subtype", subcluter_name, "\n")
    # Identify the top highly correlated non-self-expressed genes from the adjusted correlation matrix
    highCorNonSelfGenes <- highCorGene(
      subcluter_name = subcluter_name,
      cellMetaData = cellMetaData, ScExMatrix = ScExMatrix,
      cor_matrix = cor_matrix, TopMethod = TopMethod
    )
    # cat(highCorNonSelfGenes$CorGeneRank[1:10], "\n")

    # Enrichment analysis for a specific cell subtype
    for (otherType in allClusters) {
      subtypeEnrichScore <- EnrichCorGene(
        subcluter_name2 = otherType,
        topCorGene = names(highCorNonSelfGenes$CorGeneRank[1:topGeneNum]),
        cellMetaData = cellMetaData, ScExMatrix = ScExMatrix,
        Sub_Cluster = "Sub_Cluster", CellName = "CellName"
      )

      names(subtypeEnrichScore) <- otherType
      # cat(as.character(subcluter_name), as.character(otherType), subtypeEnrichScore, "\n")

      if (match(otherType, allClusters) == 1) {
        subtypeEnrichScoreVector <- c(subtypeEnrichScore)
      } else {
        subtypeEnrichScoreVector <- append(subtypeEnrichScoreVector, subtypeEnrichScore)
      }
    }
    subtypeEnrichScoreTemp <- data.frame(
      specificSubtype = subcluter_name,
      otherSubtype = names(Z_score(na.omit(subtypeEnrichScoreVector))),
      EnrichScore = Z_score(na.omit(subtypeEnrichScoreVector))
    ) %>% remove_rownames()
    if (match(subcluter_name, specificSubtypes) == 1) {
      allTypeEnrichScore <- subtypeEnrichScoreTemp
    } else {
      allTypeEnrichScore <- rbind(allTypeEnrichScore, subtypeEnrichScoreTemp)
    }
  }
  return(allTypeEnrichScore)
}

# Run example
# test =cellCellInteraction(specificSubtypes = unique(CCgene_normal$cluster),
#                     allClusters = unique(c(CCgene_normal$cluster, CCgene_tumor$cluster)), #unique(CRC_Leukocyte_SM_MD$Sub_Cluster),
#                     cor_matrix = cor_matrix_normal,
#                     cellMetaData= CRC_Leukocyte_SM_MD,
#                     ScExMatrix=CRC_Leukocyte_SM_RNA,
#                     Sub_Cluster="Sub_Cluster",
#                     CellName="CellName",
#                     topGeneNum = 13,
#                     TopMethod="Positive")


# calTissueDist Function(): Tissue distribution of clusters
# Parameters dat.tb: data frame contain cell meta infoemation.
# Parameters colname.cluster: The column name in dat.tb represent cluster name.
# Parameters colname.tissue: The column name in dat.tb represent tissue name.
# code from https://github.com/Japrin/STARTRAC  https://github.com/Japrin/sscClust functions.R; paper: Lineage tracking reveals dynamic relationships of T cells in colorectal cancer
#' Tissue distribution of clusters
#'
#' @param dat.tb
#' @param byPatient
#' @param colname.cluster
#' @param colname.patient
#' @param colname.tissue
#'
#' @return
#' @export
#'
#' @examples
#' CRC_Leukocyte_10x_MD <- read.table("CRC.Leukocyte.10x.Metadata.txt", header = T, sep = "\t", check.names = F)
#' dim(CRC_Leukocyte_10x_MD)
#' CRC_Leukocyte_10x_MD_FIilter <- filter(CRC_Leukocyte_10x_MD, grepl("^hM", Sub_Cluster))
#' calTissueDist(CRC_Leukocyte_10x_MD_FIilter, colname.cluster = "Sub_Cluster", colname.tissue = "Tissue")
calTissueDist <- function(dat.tb, byPatient = F, colname.cluster = "majorCluster",
                          colname.patient = "patient", colname.tissue = "loc") {
  if (byPatient == F) {
    N.o <- table(dat.tb[[colname.cluster]], dat.tb[[colname.tissue]])
    res.chisq <- chisq.test(N.o)
    R.oe <- (res.chisq$observed) / (res.chisq$expected)
  } else {
    N.o.byPatient <- table(
      dat.tb[[colname.patient]],
      dat.tb[[colname.cluster]], dat.tb[[colname.tissue]]
    )
    R.oe <- apply(N.o.byPatient, 1, function(x) {
      res.chisq <- chisq.test(x)
      return((res.chisq$observed) / (res.chisq$expected))
    })
  }
  return(R.oe)
}

# Run example
# CRC.Leukocyte.10x.Metadata.txt: https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE146771
# CRC_Leukocyte_10x_MD = read.table("CRC.Leukocyte.10x.Metadata.txt",header = T, sep="\t", check.names = F)
# CRC_Leukocyte_10x_MD_FIilter = filter(CRC_Leukocyte_10x_MD, grepl("^hM",Sub_Cluster))
# calTissueDist(CRC_Leukocyte_10x_MD_FIilter,colname.cluster="Sub_Cluster", colname.tissue="Tissue")
