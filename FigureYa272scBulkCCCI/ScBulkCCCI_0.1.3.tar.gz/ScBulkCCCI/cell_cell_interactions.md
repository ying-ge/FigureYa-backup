**Correlative cell-cell interactions inferred by combined scRNA-seq and TCGA datasets**

**# 1. Cell subtype abundance estimated from bulk expression profiles**

**## 1.1 Tissue distribution of clusters**

To quantify the cell type enrichment across tissues(Tumor, Normal, Blood), comparing the observed and expected cell numbers in each cluster based on the Chi-square test to obtain Ro/e values.Ro/e > 1 mean enrichment.
$$
R_{o\over e} = {Observed \over Expected}
$$

- Calculate method:

```
calTissueDist(dat.tb,byPatient=F,colname.cluster="majorCluster", colname.patient="patient",colname.tissue="loc")
```

**## 1.2 Identifing cell cluster marker gene** 

The specific gene signatu [20220117.cell-cell interactions.md](20220117.cell-cell interactions.md) res for each subtype: 

1. FDR adjusted P-value of F test < 0.05; 
2. Any cluster pair showed significant difference in the HSD test (absolute log2 fold change > 1 and P- value adjusted by Tukey’s ‘Honest Significant Difference’ method < 0.01);
3. AUC > 0.65; 
4. Typical marker genes described in literatures.

- Calculate method:

```
Seurat package
```

**## 1.3 Evaluate the abundance of each cluster based on bulk RNAseq data and marker genes**

- For tumor-enriched clusters, The TCGA COAD and READ data were used to evaluate the abundance of each cluster

- The GTEx colon tissue data were used for normal-enriched clusters.

  **Method: estimated the relative abundance of each cell subtype by the average expression of z-score normalized log-transformed expression of the cell type specific genes**

**# 2. Gene expression and cell subtype abundance correlation matrix**

1. Construct correlation matrix: Computed the Pearson correlation coefficient between the expression of each gene and the relative abundance of each cell subtype.
2. Identify self-expressed genes for each cell subtype: Smart-seq2 dataset according to the following criteria: (1) average expression > 1; (2) cell frequency of expression > 20%.
3. Adjusted correlation matrix: Adjust self-expressed genes in correlation matrix - transformed their correlation values to 0.

> The top 13 highly correlated non-self-expressed genes were selected from the adjusted correlation matrix. - For a specific cell subtype

```
# Cell subtype abundance correlation matrix
corMatrix(CCgene_info, cluster = "cluster",dataMerge_allgene, corMethod="pearson")
# Identify highly correlated genes
highCorGene(subcluter_name, cellMetaData, Sub_Cluster="Sub_Cluster", CellName="CellName",ScExMatrix, cor_matrix, TopMethod="Positive")
```

**# 3.Enrichment analysis for highly correlated genes**

- Cells expression profiles of each  subclass were extracted separately from Smart-seq2 data ；
- In subtype cluster data, gene expression was first averaged across each cell subtype and then z-score was performed.
- The top 13 highly correlated non-self-expressed genes of a specific cell subtype were selected from the adjusted correlation matrix.
- The mean value of z-score transformed expression of top 13 genes in each cell subtype as the enrichment score.
- The correlated cell subtype(s) was identified as the z-score transformed enrichment score > 1.96

```
EnrichCorGene(subcluter_name2, topCorGene, cellMetaData, Sub_Cluster="Sub_Cluster", CellName="CellName", ScExMatrix)
```

**# Notes:**

1. The lists of cell subtype specific genes were provided in Table S4A of [Single-Cell Analyses Inform Mechanisms of Myeloid-Targeted Therapies in Colon Cancer](https://pubmed.ncbi.nlm.nih.gov/32302573/#:~:text=Single-Cell Analyses Inform Mechanisms of Myeloid-Targeted Therapies in,toward dissecting mechanisms underlying immune-modulating therapies is scarce.): hT06_CD4-CXCR5 -> hT06_CD4-CXCR5；

2. hE01_Endothelium-CDH5 is were provided in Table S4A(Paper: Single-Cell Analyses Inform Mechanisms of Myeloid-Targeted Therapies in Colon Cancer), however, it doesn't exist in the Smart-seq2 cell Meta data file.

3. The selection of top highly correlated non-self-expressed genes number :  It is suggested to adjust the number of genes when the enrichment score of specific cell subtype own close to 0,  because enrichment score is transformed by z-score For each specific cell subtype；

   ```
   A specific cell subtype   A specific cell subtype = 0
   ```

4. The correlative networks in tumor and normal mucosa were built separately with corresponding correlated cell subtypes: So there is no need to correct batch effect.

5. It is worth mentioning that some samples in GTEX with poor quality data, it will result in NA for genes or samples analysis, which hich is solved by removing incomplete cases (na.omit()). 

```
	GTEX-WFG8-1726-SM-5CHTE	GTEX-WFON-1426-SM-5CHT1	GTEX-SUCS-1026-SM-5CHTC	GTEX-WFG8-1526-SM-5CHSI
CLU	-9.9658	-9.9658	-9.9658	-9.9658
CD81	-9.9658	-9.9658	-9.9658	-9.9658
ITM2C	-9.9658	-9.9658	-9.9658	-9.9658
LGALS3BP	-9.9658	-9.9658	-9.9658	-9.9658
SERPINF1	-9.9658	-9.9658	-9.9658	-9.9658
NR4A1	-9.9658	-9.9658	-9.9658	-9.9658
C1QB	-9.9658	-9.9658	-9.9658	-9.9658
GABARAPL1	-9.9658	-9.9658	-9.9658	-9.9658
```

Before analysis, poor quality data is expected to be removed. 

```
For gene: data[!(apply(data, 1, function(x){ all(x==mean(x))})),]
For sample: data[!(apply(data, 2, function(x){ all(x==mean(x))})),]
```

However,  that ruled out only some poor quality data by method mentioned aboved.

**# 4. Run pipeline**

- Data preprocess

`ScBulkCCCI_DataPreprocess.R` in `./tests`for preprocess data from paper: [Single-Cell Analyses Inform Mechanisms of Myeloid-Targeted Therapies in Colon Cancer](https://pubmed.ncbi.nlm.nih.gov/32302573/#:~:text=Single-Cell Analyses Inform Mechanisms of Myeloid-Targeted Therapies in,toward dissecting mechanisms underlying immune-modulating therapies is scarce.)

- Run Enrichment analysis
  1. Import data

```
library("pheatmap")
library("RColorBrewer")
library("ScBulkCCCI")

# Import data

## Import ScRNAseq Smart-seq2
CRC_Leukocyte_SM_MD = read.table("./data/CRC.Leukocyte.Smart-seq2.Metadata.txt",header = T, sep="\t", check.names = F);dim(CRC_Leukocyte_SM_MD)
CRC_Leukocyte_SM_RNA = read.table("./data/CRC.Leukocyte.Smart-seq2.TPM.txt",header = T)
# CRC_Leukocyte_SM_MD = readRDS("CRC.Leukocyte.Smart-seq2.Metadata.rds");dim(CRC_Leukocyte_SM_MD)
# CRC_Leukocyte_SM_RNA = readRDS("CRC.Leukocyte.Smart-seq2.TPM.rds");dim(CRC_Leukocyte_SM_RNA)

## Import gene signatures for each subtype from Smart-seq2
CCgene_normal = readRDS("./data/CCgene_normal.rds")
CCgene_tumor = readRDS("./data/CCgene_tumor.rds")

## Import bulk expression profiles
dataMerge_normal_allgene = readRDS("./data/dataMerge_normal_allgene.rds")
dataMerge_tumor_allgene = readRDS("./data/dataMerge_tumor_allgene.rds")



# Construct cell subtype abundance correlation matrix
cor_matrix_normal = corMatrix(CCgene_normal, cluste = "cluster", dataMerge_normal_allgene);dim(cor_matrix_normal) #14783    17
cor_matrix_tumor = corMatrix(CCgene_tumor, cluste = "cluster", dataMerge_tumor_allgene);dim(cor_matrix_tumor) #13194    22
```

2. Tissue distribution of clusters

```
#CRC.Leukocyte.10x.Metadata.txt: https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE146771
CRC_Leukocyte_10x_MD = read.table("./data/CRC.Leukocyte.10x.Metadata.txt",header = T, sep="\t", check.names = F);dim(CRC_Leukocyte_10x_MD)
CRC_Leukocyte_10x_MD_FIilter = filter(CRC_Leukocyte_10x_MD, grepl("^hM",Sub_Cluster))
Roe = calTissueDist(CRC_Leukocyte_10x_MD_FIilter,colname.cluster="Sub_Cluster", colname.tissue="Tissue")
pheatmap::pheatmap(Roe, cluster_rows = F, cluster_cols = F, color = colorRampPalette(brewer.pal(n = 7, name ="YlOrRd"))(50),
                   display_numbers = TRUE,number_color = "black")
```

<img src="./tests/Tissuedistributionofclusters.png" width="100%" />

3. Enrichment analysis for highly correlated genes

1. For a specific cell subtype and another cell subtype

```
### Case 1.1 Obtain the ranked correlated non-self-expressed genes for a specific cell subtype
##highCorGene Function(): 
##Achievement: the ranked correlated non-self-expressed genes from the adjusted correlation matrix for a specific cell subtype
##step 1. Identify self-expressed genes
##step 2. Adjust correlation matrix by self-expressed genes
subcluter_name= unique(CCgene_normal$cluster)[1] #unique(CCgene_normal$cluster)[1] #unique(CCgene_normal$cluster)[1]


highCorNonSelfGenes = highCorGene(subcluter_name= subcluter_name,
                                  Sub_Cluster="Sub_Cluster", CellName="CellName",
                                  cellMetaData= CRC_Leukocyte_SM_MD, ScExMatrix=CRC_Leukocyte_SM_RNA,
                                  cor_matrix=cor_matrix_normal,TopMethod="Positive")
highCorNonSelfGenes$correlatioRankPlot
```



<img src="./tests/correlatioRankPlot.png" width="100%" />

2. For a specific cell subtype and multiple cell subtype

```
allClusters = unique(c(CCgene_normal$cluster, CCgene_tumor$cluster)) #unique(CRC_Leukocyte_SM_MD$Sub_Cluster)

ES = oneToMultiple(allClusters= allClusters,
                   topCorGene=names(highCorNonSelfGenes$CorGeneRank[1:13]),
                   cellMetaData= CRC_Leukocyte_SM_MD, ScExMatrix=CRC_Leukocyte_SM_RNA,
                   Sub_Cluster="Sub_Cluster", CellName="CellName")
scale(na.omit(ES))
ESData = data.frame(name = rownames(scale(na.omit(ES))),ES=scale(na.omit(ES)))
ESData$colorInfo = as.factor(ifelse(ESData$ES>0, "pos", "neg"))
library(ggplot2)
library(ggthemes)
ggplot() + geom_bar(data = ESData,aes(x=name, y=ES, fill=colorInfo),stat = "identity") + 
  geom_hline(yintercept=1, color="blue", linetype="dashed") +
  scale_fill_manual(values=c("#87CEFA", "#6495ED")) +
  labs(x = "Correlative cell cluster", y = "Enrichment score", title = paste("Enrichment analysis for",subcluter_name,sep = " ")) +
  theme_base() +
  theme(axis.text.x = element_text(size = 15, vjust = 0.5, hjust = 0.5, angle = 90)) + 
  theme(legend.position="none") +
  theme(plot.title = element_text(hjust = 0.5))
```

<img src="./tests/Enrichmentanalysisforaspecificcellsubtype.png" width="100%" />

3. For multiple cell subtypes and multiple cell subtypes

```
allClusters = unique(c(CCgene_normal$cluster, CCgene_tumor$cluster)) #unique(c(CCgene_normal$cluster, CCgene_tumor$cluster)) #unique(CRC_Leukocyte_SM_MD$Sub_Cluster)
topGeneNum=13
{
  normal_subtype_ES = cellCellInteraction(specificSubtypes = unique(CCgene_normal$cluster),
                                          allClusters = allClusters, # unique(c(CCgene_normal$cluster, CCgene_tumor$cluster)), #unique(CRC_Leukocyte_SM_MD$Sub_Cluster)
                                          cor_matrix = cor_matrix_normal,
                                          cellMetaData= CRC_Leukocyte_SM_MD,
                                          ScExMatrix=CRC_Leukocyte_SM_RNA,
                                          Sub_Cluster="Sub_Cluster",
                                          CellName="CellName",
                                          topGeneNum = topGeneNum,
                                          TopMethod="Positive")
  
  tumor_subtype_ES = cellCellInteraction(specificSubtypes = unique(CCgene_tumor$cluster),
                                         allClusters = allClusters,#unique(c(CCgene_normal$cluster, CCgene_tumor$cluster)),
                                         cor_matrix = cor_matrix_tumor,
                                         cellMetaData= CRC_Leukocyte_SM_MD,
                                         ScExMatrix=CRC_Leukocyte_SM_RNA,
                                         Sub_Cluster="Sub_Cluster",
                                         CellName="CellName",
                                         topGeneNum = topGeneNum,
                                         TopMethod="Positive")
}



```

4. Compare the result of correlative cell cell interactions between ScBulkCCCI and paper.

```
 normal_subtype_ES$tissue = "normal"
  tumor_subtype_ES$tissue = "tumor"

  subtype_ES = rbind(normal_subtype_ES,tumor_subtype_ES)
  dplyr::filter(subtype_ES, grepl("^hM03", specificSubtype), EnrichScore>1)
  dplyr::filter(subtype_ES, grepl("^hM04", specificSubtype), EnrichScore>1)
  dplyr::filter(subtype_ES, grepl("^hM13", specificSubtype), EnrichScore>1)
  dplyr::filter(subtype_ES, grepl("^hM12", specificSubtype), EnrichScore>1)
  
  write.table(subtype_ES, file = "Correlative.cell_cell.interactions.txt", quote = F, row.names = F, sep = "\t") #unique(CRC_Leukocyte_SM_MD$Sub_Cluster)
```

- - The  enrichment analysis result of  `hM13_TAM-SPP1`  from ScBulkCCCI is the same result as paper  show .

```
dplyr::filter(subtype_ES, grepl("^hM13", specificSubtype), EnrichScore>1)
  specificSubtype      otherSubtype EnrichScore tissue
hM13_TAM-SPP1 hF01_Myofib-ACTA2    2.518859  tumor
hM13_TAM-SPP1      hF02_CAF-FAP    4.083852  tumor
```

- - What's more, the enrichment analysis results of hM03, hM04 or hM12 are not identical, , but they are similar.

5.  Plot the result of Enrichment analysis

- Plot network by igraph

```
library("igraph")
tumor_subtype_ES= read.table("tumor_subtype.Correlative.cell_cell.interactions.txt", header = T, sep = "\t")
networkData = dplyr::filter(tumor_subtype_ES, EnrichScore>1.96, specificSubtype != otherSubtype)
CRC_Leukocyte_SM_MD = read.table("CRC.Leukocyte.Smart-seq2.Metadata.txt",header = T, sep="\t", check.names = F);dim(CRC_Leukocyte_SM_MD)
overlap = intersect(unique(c(networkData$specificSubtype,networkData$otherSubtype)), CRC_Leukocyte_SM_MD$Sub_Cluster)

nodes <- dplyr::filter(CRC_Leukocyte_SM_MD,Sub_Cluster %in% overlap) %>%
  select(Sub_Cluster, Global_Cluster) %>%
  dplyr::distinct(Sub_Cluster,Global_Cluster) 

nodes = merge(data.frame(node = unique(c(networkData$specificSubtype,networkData$otherSubtype))), nodes, by.x="node", by.y="Sub_Cluster", all = T)
nodes[is.na(nodes)] ="Not annotation"


g <- graph_from_data_frame(networkData, directed=F, vertices=nodes)
V(g)$label.cex=0.75
V(g)$label.color <- "black"
V(g)$color <- brewer.pal(n = 12, name ="Paired")[as.numeric(as.factor(V(g)$Global_Cluster))]
V(g)$frame.color <- "white"
plot(g)

legend(x=-1.5, y= 1, unique(as.factor(V(g)$Global_Cluster)), pch=21,
       col="#777777", pt.bg=unique(brewer.pal(n = 12, name ="Paired")[as.numeric(as.factor(V(g)$Global_Cluster))]), 
       pt.cex=2, cex=.8, bty="n", ncol=1)

```

<img src="./tests/network.png" width="100%" />

- Plot dynamic network

```
library(magrittr)
library(networkD3)
nodeData <- data.frame(name=nodes$node,
                       group= as.factor(nodes$Global_Cluster))
linkData <- data.frame(source = (match(networkData$specificSubtype, nodeData$name)-1),
                       target = (match(networkData$otherSubtype, nodeData$name)-1))
forceNetwork(
  Links = linkData,
  Nodes = nodeData,
  Source = "source",
  Target = "target",
  NodeID = "name",Group = "group", legend = T, opacityNoHover = 1,zoom=T) %>%
  saveNetwork(file = 'network.html')

```

 [network.html](./tests/network.html) 

**Data used in this project**

- CRC.Leukocyte.Smart-seq2.Metadata.txt: GEO: GSE146771
- CRC.Leukocyte.Smart-seq2.TPM.txt: GEO: GSE146771
- T4.Normal_enriched.txt: Table S4A of paper
- T4.Tumor_enriched.txt: Table S4A of paper
- GTEX_phenotype: [UCSC Xena (xenabrowser.net)](https://xenabrowser.net/datapages/?cohort=GTEX&removeHub=https%3A%2F%2Fxena.treehouse.gi.ucsc.edu%3A443)
- gtex_RSEM_gene_tpm: [UCSC Xena (xenabrowser.net)](https://xenabrowser.net/datapages/?cohort=GTEX&removeHub=https%3A%2F%2Fxena.treehouse.gi.ucsc.edu%3A443)
- GTEX.probeMap_gencode.v23.annotation.gene.probemap:  [UCSC Xena (xenabrowser.net)](https://xenabrowser.net/datapages/?cohort=GTEX&removeHub=https%3A%2F%2Fxena.treehouse.gi.ucsc.edu%3A443)
- TCGA.COADREAD.sampleMap_COADREAD_clinicalMatrix: [UCSC Xena (xenabrowser.net)](https://xenabrowser.net/datapages/?cohort=TCGA Colon and Rectal Cancer (COADREAD)&removeHub=https%3A%2F%2Fxena.treehouse.gi.ucsc.edu%3A443)
- TCGA.COADREAD.sampleMap_HiSeqV2: [UCSC Xena (xenabrowser.net)](https://xenabrowser.net/datapages/?cohort=TCGA Colon and Rectal Cancer (COADREAD)&removeHub=https%3A%2F%2Fxena.treehouse.gi.ucsc.edu%3A443)
- TCGA.probeMap_hugo_gencode_good_hg19_V24lift37_probemap: [UCSC Xena (xenabrowser.net)](https://xenabrowser.net/datapages/?cohort=TCGA Colon and Rectal Cancer (COADREAD)&removeHub=https%3A%2F%2Fxena.treehouse.gi.ucsc.edu%3A443)

**Reference**

Zhang L, Li Z, Skrzypczynska KM, Fang Q, Zhang W, O'Brien SA, He Y, Wang L, Zhang Q, Kim A, Gao R, Orf J, Wang T, Sawant D, Kang J, Bhatt D, Lu D, Li CM, Rapaport AS, Perez K, Ye Y, Wang S, Hu X, Ren X, Ouyang W, Shen Z, Egen JG, Zhang Z, Yu X. Single-Cell Analyses Inform Mechanisms of Myeloid-Targeted Therapies in Colon Cancer. Cell. 2020 Apr 16;181(2):442-459.e29. doi: 10.1016/j.cell.2020.03.048. PMID: 32302573.

Zhang L, Yu X, Zheng L, Zhang Y, Li Y, Fang Q, Gao R, Kang B, Zhang Q, Huang JY, Konno H, Guo X, Ye Y, Gao S, Wang S, Hu X, Ren X, Shen Z, Ouyang W, Zhang Z. Lineage tracking reveals dynamic relationships of T cells in colorectal cancer. Nature. 2018 Dec;564(7735):268-272. doi: 10.1038/s41586-018-0694-x. Epub 2018 Oct 29. PMID: 30479382.

