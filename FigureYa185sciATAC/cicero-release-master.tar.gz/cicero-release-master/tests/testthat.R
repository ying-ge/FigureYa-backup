library(testthat)
library(cicero)

test_check("cicero")
